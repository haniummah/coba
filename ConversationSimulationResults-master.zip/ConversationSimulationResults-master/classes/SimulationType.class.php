<?php

class SimulationType
{
    const GRADED = 'graded';
    const SURVEY = 'survey';
}
